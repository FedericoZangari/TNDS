#pragma once

#include <algorithm> // se se vogliono usare algoritmi STL
#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

//////////////////////////////////////////////////////////////
// Nel namespace myVectAlgebra potremmo ridefinire gli operatori
// matematici che coinvolgono vettori e scalari

// somma di due vettori : somma componente per componente

template <typename T>
std::vector<T> operator+(const std::vector<T> &a, const std::vector<T> &b) {

  assert(a.size() == b.size());
  std::vector<T> result(a.size());

  for (size_t i{}; i < a.size(); i++)
    result[i] = a[i] + b[i];

  // Alternativamente si puo' usare l'algoritmo transform della STL
  //
  //    std::transform(a.begin(), a.end(), b.begin(), result.begin() ,
  //    std::plus<T>());

  return result;
}

// differenza di due vettori componente per componente
// [ preferisco re-implementarlo perche' si fanno meno operazioni rispetto
// result = a + (-1.*b) ]

template <typename T>
std::vector<T> operator-(const std::vector<T> &a, const std::vector<T> &b) {

  assert(a.size() == b.size());
  std::vector<T> result(a.size());

  for (size_t i{}; i < a.size(); i++)
    result[i] = a[i] - b[i];

  // Alternativamente si puo' usare l'algoritmo transform della STL
  //
  //    std::transform(a.begin(), a.end(), b.begin(), result.begin() ,
  //    std::minus<T>());

  return result;
}

//////////////////////////////////////////////////////////////
// prodotto scalare tra due vettori

template <typename T>
T operator*(const std::vector<T> &a, const std::vector<T> &b) {

  assert(a.size() == b.size());
  T sum{};
  for (size_t i{}; i < a.size(); i++)
    sum += a[i] * b[i];

  // Alternativamente si puo' usare l'algoritmo inner_product della STL
  //
  // sum = std::inner_product(std::begin(a), std::end(a), std::begin(b), 0.);

  return sum;
}

//////////////////////////////////////////////////////////////
// prodotto tra uno scalare e un vettore

template <typename T> std::vector<T> operator*(T c, const std::vector<T> &a) {

  std::vector<T> result(a.size());

  for (size_t i{}; i < a.size(); i++)
    result[i] = c * a[i];

  // Alternativamente si puo' usare l'algoritmo inner product
  //
  //     std::transform(std::begin(a), std::end(a), std::begin(result), [&c](T
  //     x){ return x * c; } );

  return result;
}

//////////////////////////////////////////////////////////////
// prodotto tra un vettore e uno scalare

template <typename T> std::vector<T> operator*(const std::vector<T> &a, T c) {

  std::vector<T> result(a.size());
  for (size_t i{}; i < a.size(); i++)
    result[i] = c * a[i];

  // oppure il ciclo for puo' essere sostituito da ( ~ stesso numero di
  // operazioni con il move constructor del vector altrimenti sarebbe meno
  // efficiente )
  //
  // result = c * a ;

  // Alternativamente si puo' usare l'algoritmo transform della STL con una
  // lambda function
  //
  //    std::transform(std::begin(a), std::end(a), std::begin(result), [&c](T
  //    x){ return x * c; } );

  return result;
}

//////////////////////////////////////////////////////////////
// divisione tra un vettore e uno scalare

template <typename T> std::vector<T> operator/(const std::vector<T> &a, T c) {

  std::vector<T> result(a.size());
  for (size_t i{}; i < a.size(); i++)
    result[i] = a[i] / c;

  // oppure il ciclo for puo' essere sostituito da

  // double fact = 1./c
  // result = a * fact ;

  // Alternativamente si puo' usare l'algoritmo transform della STL con una
  // lambda function
  //
  //    std::transform(std::begin(a), std::end(a), std::begin(result), [&c](T
  //    x){ return x / c; } );

  return result;
}

//////////////////////////////////////////////////////////////
// somma ad a un vettore b e il risultato viene messo in a

template <typename T>
std::vector<T> &operator+=(std::vector<T> &a, const std::vector<T> &b) {

  assert(a.size() == b.size());

  for (size_t i{}; i < a.size(); i++)
    a[i] += b[i];

  // Alternativamente si puo' usare l'algoritmo transform della STL
  //
  //    std::transform(a.begin(), a.end(), b.begin(), a.begin() ,
  //    std::plus<T>());

  return a;
}

//////////////////////////////////////////////////////////////
// sottrai ad a un vettore b e il risultato viene messo in a

template <typename T>
std::vector<T> &operator-=(std::vector<T> &a, const std::vector<T> &b) {

  assert(a.size() == b.size());

  for (size_t i{}; i < a.size(); i++)
    a[i] -= b[i];

  // Alternativamente si puo' usare l'algoritmo transform della STL
  //
  //    std::transform(a.begin(), a.end(), b.begin(), a.begin() ,
  //    std::minus<T>());

  return a;
}


// prodotta tra matrice e vettore
template <typename T> std::vector<T> operator&(  vector< vector<T>> &a,  std::vector<T> &v) {

  assert(a[0].size() == v.size());
  std::vector<T> result(v.size());
  result = NULL;

  for (size_t i{}; i < v.size(); i++)
      result[i] = a[i] * v;


  return result;
}
/*
template <class T>
std::vector <std::vector<T>> Multiply(std::vector <std::vector<T>> &a, std::vector <std::vector<T>> &b)
{
    const int n = a.size();     // a rows
    const int m = a[0].size();  // a cols
    const int p = b[0].size();  // b cols

    std::vector <std::vector<T>> c(n, std::vector<T>(p, 0));
    for (auto j = 0; j < p; ++j)
    {
        for (auto k = 0; k < m; ++k)
        {
            for (auto i = 0; i < n; ++i)
            {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }
    return c;
}
*/
//////////////////////////////////////////////////////////////
// Possiamo usare il namespace myVectUtils per funzioni generiche che
// agiscono sui vettori

namespace myVectUtils {

// metodo comodo per stampare il vettore

template <typename T> void Print(const std::vector<T> &v) {
  std::cout << "Printing vector\n";
  for (auto elem : v)
    std::cout << v << " ";
  std::cout << "\n";
  std::cout << "End of printing vector\n";
}

} // namespace myVectUtils
