#ifndef __funzionebase_h__
#define __funzionebase_h__

class FunzioneBase{
public:
  virtual double Eval(double x) const = 0;
};
#endif

    